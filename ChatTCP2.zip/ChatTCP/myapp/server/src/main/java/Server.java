import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class Server {
    private static Map<String, Set<PrintWriter>> groups = new HashMap<>();
    private static Chatters clientes = new Chatters();
    private static Map<String, Socket> callConnections = new ConcurrentHashMap<>();
    private static final int PORT = 6565;
    private static final int FILE_PORT = 7000;
    private static final int CALL_PORT = 8000;
    private static final AtomicBoolean running = new AtomicBoolean(true);

    public static void main(String[] args) {
        try (ServerSocket messageServerSocket = new ServerSocket(PORT);
             ServerSocket fileServerSocket = new ServerSocket(FILE_PORT);
             ServerSocket callServerSocket = new ServerSocket(CALL_PORT)) {

            System.out.println("Servidor iniciado. Esperando clientes...");
            System.out.println("Servidor de mensajes en puerto: " + PORT);
            System.out.println("Servidor de archivos en puerto: " + FILE_PORT);
            System.out.println("Servidor de llamadas en puerto: " + CALL_PORT);

            Thread messageThread = new Thread(() -> handleConnections(messageServerSocket, "mensaje", running));
            Thread fileThread = new Thread(() -> handleConnections(fileServerSocket, "archivo", running));
            Thread callThread = new Thread(() -> handleConnections(callServerSocket, "llamada", running));

            messageThread.start();
            fileThread.start();
            callThread.start();

            System.out.println("Presione Enter para detener el servidor");
            new BufferedReader(new InputStreamReader(System.in)).readLine();

            running.set(false);
            messageServerSocket.close();
            fileServerSocket.close();
            callServerSocket.close();

            messageThread.join();
            fileThread.join();
            callThread.join();

        } catch (IOException | InterruptedException e) {
            System.out.println("Error al iniciar el servidor: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("Servidor detenido.");
    }

    private static void handleConnections(ServerSocket serverSocket, String type, AtomicBoolean running) {
        while (running.get()) {
            try {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nueva conexión de " + type + ": " + clientSocket);
                if (type.equals("mensaje")) {
                    ClientHandler clientHandler = new ClientHandler(clientSocket, clientes, groups);
                    new Thread(clientHandler).start();
                } else if (type.equals("archivo")) {
                    new Thread(() -> handleFileTransfer(clientSocket)).start();
                } else if (type.equals("llamada")) {
                    new Thread(() -> handleCall(clientSocket)).start();
                }
            } catch (SocketException e) {
                if (running.get()) {
                    System.out.println("Error al aceptar conexión de " + type + ": " + e.getMessage());
                }
            } catch (IOException e) {
                System.out.println("Error al aceptar conexión de " + type + ": " + e.getMessage());
            }
        }
    }

    private static void handleFileTransfer(Socket fileSocket) {
        try (DataInputStream dis = new DataInputStream(fileSocket.getInputStream());
             FileOutputStream fos = new FileOutputStream("server_received_file.tmp")) {

            long fileSize = dis.readLong();
            byte[] buffer = new byte[4096];
            int bytesRead;
            long totalBytesRead = 0;

            while (totalBytesRead < fileSize && (bytesRead = dis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalBytesRead += bytesRead;
                System.out.printf("Recibiendo archivo: %.2f%%\r", (totalBytesRead * 100.0) / fileSize);
            }
            fos.flush();
            System.out.println("\nArchivo recibido correctamente.");
        } catch (IOException e) {
            System.out.println("Error al recibir archivo: " + e.getMessage());
        }
    }

    private static void handleCall(Socket callSocket) {
        try (DataInputStream dis = new DataInputStream(callSocket.getInputStream());
             DataOutputStream dos = new DataOutputStream(callSocket.getOutputStream())) {

            String caller = dis.readUTF();
            String callee = dis.readUTF();

            System.out.println(caller + " está llamando a " + callee);

            synchronized (callConnections) {
                callConnections.put(caller, callSocket);
            }

            PrintWriter calleeWriter = clientes.getWriter(callee);
            if (calleeWriter != null) {
                calleeWriter.println("INCOMING_CALL " + caller);
                String response = dis.readUTF();

                if ("ACCEPT".equals(response)) {
                    dos.writeUTF("CALL_ACCEPTED");
                    dos.flush();

                    Socket calleeSocket = callConnections.get(callee);
                    if (calleeSocket != null) {
                        new Thread(() -> forwardAudio(callSocket, calleeSocket)).start();
                        new Thread(() -> forwardAudio(calleeSocket, callSocket)).start();
                    }
                } else {
                    dos.writeUTF("CALL_REJECTED");
                    dos.flush();
                }
            } else {
                dos.writeUTF("USER_NOT_FOUND");
                dos.flush();
            }

        } catch (IOException e) {
            System.out.println("Error durante la llamada: " + e.getMessage());
        } finally {
            synchronized (callConnections) {
                callConnections.remove(caller);
            }
        }
    }

    private static void forwardAudio(Socket from, Socket to) {
        try (InputStream is = from.getInputStream();
             OutputStream os = to.getOutputStream()) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
                os.flush();
            }
        } catch (IOException e) {
            System.out.println("Error al reenviar audio: " + e.getMessage());
        }
    }
}