import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Chatters {
    private Map<String, PrintWriter> clientes = new ConcurrentHashMap<>();
    private Map<String, String> activeCallPairs = new ConcurrentHashMap<>();

    public synchronized void addUsr(String userName, PrintWriter out) {
        clientes.put(userName, out);
    }

    public synchronized void removeUsr(String userName) {
        clientes.remove(userName);
        removeFromActiveCall(userName);
    }

    public synchronized void broadcastMessage(String message) {
        for (PrintWriter writer : clientes.values()) {
            writer.println(message);
        }
    }

    public synchronized void privateMessage(String user, String message) {
        PrintWriter out = clientes.get(user);
        if (out != null) {
            out.println(message);
        } else {
            System.out.println("Usuario no encontrado: " + user);
        }
    }

    public synchronized boolean existeUsr(String userName) {
        return clientes.containsKey(userName);
    }

    public Set<String> getConnectedUsers() {
        return clientes.keySet();
    }

    public PrintWriter getWriter(String userName) {
        return clientes.get(userName);
    }

    public synchronized void addActiveCall(String caller, String callee) {
        activeCallPairs.put(caller, callee);
        activeCallPairs.put(callee, caller);
    }

    public synchronized void removeFromActiveCall(String user) {
        String otherUser = activeCallPairs.remove(user);
        if (otherUser != null) {
            activeCallPairs.remove(otherUser);
            PrintWriter otherUserWriter = clientes.get(otherUser);
            if (otherUserWriter != null) {
                otherUserWriter.println("CALL_ENDED La llamada ha terminado.");
            }
        }
    }

    public synchronized boolean isInCall(String user) {
        return activeCallPairs.containsKey(user);
    }

    public synchronized String getCallPartner(String user) {
        return activeCallPairs.get(user);
    }
}