import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class Server {
    private static Map<String, Set<PrintWriter>> groups = new HashMap<>();
    private static Chatters clientes = new Chatters();
    private static Map<String, Socket> callConnections = new HashMap<>();
    private static final int PORT = 6565;
    private static final int FILE_PORT = 7000;
    private static final int CALL_PORT = 8000;
    private static final AtomicBoolean running = new AtomicBoolean(true);

    public static void main(String[] args) {
        try (ServerSocket messageServerSocket = new ServerSocket(PORT);
                ServerSocket fileServerSocket = new ServerSocket(FILE_PORT);
                ServerSocket callServerSocket = new ServerSocket(CALL_PORT)) { // Agregar ServerSocket para llamadas

            System.out.println("Servidor iniciado. Esperando clientes...");
            System.out.println("Servidor de mensajes en puerto: " + PORT);
            System.out.println("Servidor de archivos en puerto: " + FILE_PORT);
            System.out.println("Servidor de llamadas en puerto: " + CALL_PORT); // Mensaje para las llamadas

            Thread messageThread = new Thread(() -> handleConnections(messageServerSocket, "mensaje", running));
            Thread fileThread = new Thread(() -> handleConnections(fileServerSocket, "archivo", running));
            Thread callThread = new Thread(() -> handleConnections(callServerSocket, "llamada", running)); // Hilo para
                                                                                                           // llamadas

            messageThread.start();
            fileThread.start();
            callThread.start(); // Iniciar el hilo para llamadas

            // Esperar a que el usuario presione Enter para detener el servidor
            System.out.println("Presione Enter para detener el servidor");
            new BufferedReader(new InputStreamReader(System.in)).readLine();

            running.set(false);
            messageServerSocket.close();
            fileServerSocket.close();
            callServerSocket.close(); // Cerrar el socket de llamadas

            messageThread.join();
            fileThread.join();
            callThread.join(); // Esperar a que termine el hilo de llamadas

        } catch (IOException | InterruptedException e) {
            System.out.println("Error al iniciar el servidor: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("Servidor detenido.");
    }

    private static void handleConnections(ServerSocket serverSocket, String type, AtomicBoolean running) {
        while (running.get()) {
            try {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Nueva conexión de " + type + ": " + clientSocket);
                if (type.equals("mensaje")) {
                    ClientHandler clientHandler = new ClientHandler(clientSocket, clientes, groups);
                    new Thread(clientHandler).start();
                } else {
                    new Thread(() -> handleFileTransfer(clientSocket)).start();
                }
                if (type.equals("llamada")) {
                    new Thread(() -> handleCall(clientSocket)).start();
                }
            } catch (SocketException e) {
                if (running.get()) {
                    System.out.println("Error al aceptar conexión de " + type + ": " + e.getMessage());
                }
            } catch (IOException e) {
                System.out.println("Error al aceptar conexión de " + type + ": " + e.getMessage());
            }
        }
    }

    private static void handleFileTransfer(Socket fileSocket) {
        try (DataInputStream dis = new DataInputStream(fileSocket.getInputStream());
                FileOutputStream fos = new FileOutputStream("server_received_file.tmp")) {

            long fileSize = dis.readLong();
            byte[] buffer = new byte[4096];
            int bytesRead;
            long totalBytesRead = 0;

            while (totalBytesRead < fileSize && (bytesRead = dis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalBytesRead += bytesRead;
                System.out.printf("Recibiendo archivo: %.2f%%\r", (totalBytesRead * 100.0) / fileSize);
            }
            fos.flush();
            System.out.println("\nArchivo recibido correctamente.");
        } catch (IOException e) {
            System.out.println("Error al recibir archivo: " + e.getMessage());
        }
    }

    private static List<DataOutputStream> callParticipants = new ArrayList<>();

    private static void handleCall(Socket callSocket) {
        try (DataInputStream dis = new DataInputStream(callSocket.getInputStream());
                DataOutputStream dos = new DataOutputStream(callSocket.getOutputStream())) {

            String caller = dis.readUTF(); // Leer el nombre del llamante
            String callee = dis.readUTF(); // Leer el nombre del llamado

            synchronized (callConnections) {
                callConnections.put(caller, callSocket);
            }

            System.out.println(caller + " está llamando a " + callee);

            // Esperar a que el llamado se conecte
            while (!callConnections.containsKey(callee)) {
                Thread.sleep(1000);
            }

            Socket calleeSocket = callConnections.get(callee);
            DataOutputStream calleeDos = new DataOutputStream(calleeSocket.getOutputStream());

            // Notificar al llamado
            calleeDos.writeUTF("INCOMING_CALL");
            calleeDos.writeUTF(caller);
            calleeDos.flush();

            // Esperar confirmación del llamado
            DataInputStream calleeDis = new DataInputStream(calleeSocket.getInputStream());
            String response = calleeDis.readUTF();

            if ("ACCEPT".equals(response)) {
                dos.writeUTF("CALL_ACCEPTED");
                dos.flush();

                // Iniciar la transmisión de audio
                new Thread(() -> forwardAudio(callSocket, calleeSocket)).start();
                new Thread(() -> forwardAudio(calleeSocket, callSocket)).start();
            } else {
                dos.writeUTF("CALL_REJECTED");
                dos.flush();
            }

        } catch (IOException | InterruptedException e) {
            System.out.println("Error durante la llamada: " + e.getMessage());
        } finally {
            synchronized (callConnections) {
                callConnections.remove(caller);
            }
        }
    }

    private static void forwardAudio(Socket from, Socket to) {
        try (InputStream is = from.getInputStream();
                OutputStream os = to.getOutputStream()) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
                os.flush();
            }
        } catch (IOException e) {
            System.out.println("Error al reenviar audio: " + e.getMessage());
        }
    }

}